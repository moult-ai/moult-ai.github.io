/**
 * Moult AI — Frontend Controller
 * Gestion multi-modèles, streaming, historique local
 */

// ==========================================
// CONFIGURATION
// ==========================================
const CONFIG = {
    DEFAULT_SERVER: localStorage.getItem('moult-server-url') || 'https://api-moult-ai.lombard-web-services.com',
    MAX_HISTORY: 50,
    STORAGE_KEY: 'moult-conversations'
};

// ==========================================
// ÉTAT GLOBAL
// ==========================================
const state = {
    currentConversationId: null,
    conversations: [],
    isLoading: false,
    models: {},
    currentProvider: 'openrouter',
    currentModel: null,
    settings: {
        serverUrl: CONFIG.DEFAULT_SERVER,
        theme: localStorage.getItem('moult-theme') || 'dark',
        fontSize: parseInt(localStorage.getItem('moult-font-size')) || 14
    }
};

// ==========================================
// DOM ELEMENTS
// ==========================================
const elements = {
    app: document.getElementById('app'),
    loader: document.getElementById('app-loader'),
    sidebar: document.getElementById('sidebar'),
    sidebarClose: document.getElementById('sidebar-close'),
    menuToggle: document.getElementById('menu-toggle'),
    chatHistory: document.getElementById('chat-history'),
    newChatBtn: document.getElementById('new-chat-btn'),
    modelSelect: document.getElementById('model-select'),
    providerBadge: document.getElementById('provider-badge'),
    messagesArea: document.getElementById('messages-area'),
    welcomeScreen: document.getElementById('welcome-screen'),
    messageInput: document.getElementById('message-input'),
    sendBtn: document.getElementById('send-btn'),
    charCount: document.getElementById('char-count'),
    streamToggle: document.getElementById('stream-toggle'),
    reasoningToggle: document.getElementById('reasoning-toggle'),
    modeSelect: document.getElementById('mode-select'),
    settingsBtn: document.getElementById('settings-btn'),
    settingsModal: document.getElementById('settings-modal'),
    modalClose: document.getElementById('modal-close'),
    serverUrlInput: document.getElementById('server-url'),
    themeOptions: document.querySelectorAll('.theme-option'),
    exportBtn: document.getElementById('export-btn'),
    toastContainer: document.getElementById('toast-container'),
    providerStatus: document.getElementById('provider-status')
};

// ==========================================
// INITIALISATION
// ==========================================
document.addEventListener('DOMContentLoaded', async () => {
    applyTheme(state.settings.theme);
    applyFontSize(state.settings.fontSize);
    loadConversations();
    await fetchModels();
    
    setTimeout(() => {
        if (elements.loader) elements.loader.classList.add('hidden');
    }, 500);
    
    setupEventListeners();
    elements.messageInput?.focus();
});

// ==========================================
// EVENT LISTENERS
// ==========================================
function setupEventListeners() {
    elements.menuToggle?.addEventListener('click', () => {
        elements.sidebar.classList.add('open');
    });
    
    elements.sidebarClose?.addEventListener('click', () => {
        elements.sidebar.classList.remove('open');
    });
    
    elements.newChatBtn?.addEventListener('click', startNewChat);
    elements.messageInput?.addEventListener('input', handleInput);
    elements.messageInput?.addEventListener('keydown', handleKeydown);
    elements.sendBtn?.addEventListener('click', sendMessage);
    elements.modelSelect?.addEventListener('change', handleModelChange);
    
    elements.settingsBtn?.addEventListener('click', () => {
        elements.settingsModal.classList.add('active');
    });
    
    elements.modalClose?.addEventListener('click', closeSettings);
    elements.settingsModal?.querySelector('.modal-overlay')?.addEventListener('click', closeSettings);
    
    elements.serverUrlInput?.addEventListener('change', (e) => {
        state.settings.serverUrl = e.target.value;
        localStorage.setItem('moult-server-url', e.target.value);
        fetchModels();
        showToast('URL du serveur mise à jour', 'success');
    });
    
    elements.themeOptions?.forEach(btn => {
        btn.addEventListener('click', () => {
            const theme = btn.dataset.theme;
            applyTheme(theme);
            elements.themeOptions.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
        });
    });
    
    // Taille de police
    const fontSizeInput = document.getElementById('font-size');
    if (fontSizeInput) {
        fontSizeInput.addEventListener('input', (e) => {
            const size = parseInt(e.target.value);
            state.settings.fontSize = size;
            localStorage.setItem('moult-font-size', size);
            applyFontSize(size);
            document.querySelector('.range-value').textContent = `${size}px`;
        });
        fontSizeInput.value = state.settings.fontSize;
    }
    
    elements.exportBtn?.addEventListener('click', exportAllConversations);
    
    document.querySelectorAll('.quick-action').forEach(btn => {
        btn.addEventListener('click', () => {
            const prompt = btn.dataset.prompt;
            elements.messageInput.value = prompt;
            handleInput();
            elements.messageInput.focus();
        });
    });
    
    document.querySelector('.main')?.addEventListener('click', (e) => {
        if (window.innerWidth <= 768 && elements.sidebar.classList.contains('open')) {
            if (!e.target.closest('.sidebar')) {
                elements.sidebar.classList.remove('open');
            }
        }
    });
}

function closeSettings() {
    elements.settingsModal.classList.remove('active');
}

function applyFontSize(size) {
    document.documentElement.style.fontSize = `${size}px`;
}

// ==========================================
// GESTION DES MODÈLES (élégante)
// ==========================================
async function fetchModels() {
    try {
        const response = await fetch(`${state.settings.serverUrl}/api/models`, {
            method: 'GET',
            headers: { 'Content-Type': 'application/json' }
        });
        
        if (!response.ok) throw new Error('Failed to fetch models');
        
        const data = await response.json();
        state.models = data.models || {};
        
        populateModelSelect();
        updateProviderStatus(data.providers || {});
        
    } catch (error) {
        console.error('Error fetching models:', error);
        showToast('Impossible de charger les modèles. Vérifiez le serveur.', 'error');
        
        state.models = {
            openrouter: [
                'nvidia/nemotron-3-nano-30b-a3b:free',
                'nvidia/nemotron-3.5-content-safety:free',
                'nvidia/nemotron-3-nano-omni-30b-a3b-reasoning:free',
                'nvidia/nemotron-nano-12b-v2-vl:free',
                'nvidia/nemotron-3-ultra-550b-a55b:free',
                'poolside/laguna-m.1:free',
                'google/gemma-4-26b-a4b-it:free'
            ],
            groq: ['llama-3.3-70b-versatile'],
            hf: ['meta-llama/Llama-3.1-70B-Instruct', 'Qwen/Qwen2.5-72B-Instruct']
        };
        populateModelSelect();
    }
}

function populateModelSelect() {
    const select = elements.modelSelect;
    if (!select) return;
    
    select.innerHTML = '';
    
    const providers = Object.keys(state.models);
    
    providers.forEach(provider => {
        const optgroup = document.createElement('optgroup');
        optgroup.label = getProviderDisplayName(provider);
        
        state.models[provider].forEach(model => {
            const option = document.createElement('option');
            option.value = `${provider}:${model}`;
            option.textContent = formatModelName(model);
            optgroup.appendChild(option);
        });
        
        select.appendChild(optgroup);
    });
    
    if (select.options.length > 0) {
        select.selectedIndex = 0;
        handleModelChange();
    }
}

function getProviderDisplayName(provider) {
    const names = {
        openrouter: 'OpenRouter',
        groq: 'GroqCloud',
        hf: 'HuggingFace'
    };
    return names[provider] || provider;
}

function formatModelName(model) {
    let name = model
        .replace(/:free$/, ' (gratuit)')
        .replace(/\//g, ' / ');
    
    // Raccourcir les noms trop longs
    if (name.length > 35) {
        name = name.substring(0, 32) + '...';
    }
    return name;
}

function handleModelChange() {
    const value = elements.modelSelect.value;
    if (!value) return;
    
    const [provider, ...modelParts] = value.split(':');
    const model = modelParts.join(':');
    
    state.currentProvider = provider;
    state.currentModel = model;
    
    // NE PAS afficher le provider dans la barre de menu
    // On le garde uniquement pour les messages
    
    // Activer/désactiver reasoning selon le modèle
    const isNemotron = model.includes('nemotron');
    elements.reasoningToggle.disabled = provider !== 'openrouter' || !isNemotron;
    if (elements.reasoningToggle.disabled) {
        elements.reasoningToggle.checked = false;
    }
}

function updateProviderStatus(providers) {
    const container = elements.providerStatus;
    if (!container) return;
    
    const providerNames = ['openrouter', 'groq', 'hf'];
    providerNames.forEach(name => {
        const statusItem = container.querySelector(`.status-item[data-provider="${name}"]`);
        if (statusItem) {
            const isOnline = providers[name];
            statusItem.classList.remove('online', 'offline');
            statusItem.classList.add(isOnline ? 'online' : 'offline');
        }
    });
}

// ==========================================
// GESTION DES CONVERSATIONS
// ==========================================
function loadConversations() {
    try {
        const stored = localStorage.getItem(CONFIG.STORAGE_KEY);
        state.conversations = stored ? JSON.parse(stored) : [];
    } catch (e) {
        state.conversations = [];
    }
    renderHistory();
}

function saveConversations() {
    localStorage.setItem(CONFIG.STORAGE_KEY, JSON.stringify(state.conversations.slice(-CONFIG.MAX_HISTORY)));
}

function startNewChat() {
    state.currentConversationId = null;
    if (elements.messagesArea) elements.messagesArea.innerHTML = '';
    elements.messagesArea?.classList.remove('active');
    if (elements.welcomeScreen) elements.welcomeScreen.style.display = 'flex';
    elements.messageInput.value = '';
    handleInput();
    renderHistory();
    
    if (window.innerWidth <= 768) {
        elements.sidebar?.classList.remove('open');
    }
}

function createConversation(title = 'Nouvelle conversation') {
    const id = Date.now().toString();
    const conversation = {
        id,
        title,
        messages: [],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
    };
    
    state.conversations.unshift(conversation);
    state.currentConversationId = id;
    saveConversations();
    renderHistory();
    
    return conversation;
}

function getCurrentConversation() {
    return state.conversations.find(c => c.id === state.currentConversationId);
}

function addMessageToConversation(role, content, metadata = {}) {
    const conversation = getCurrentConversation();
    if (!conversation) return;
    
    conversation.messages.push({
        role,
        content,
        timestamp: new Date().toISOString(),
        ...metadata
    });
    
    conversation.updatedAt = new Date().toISOString();
    
    // Mettre à jour le titre si c'est le premier message utilisateur
    if (conversation.messages.length === 1 && role === 'user') {
        conversation.title = content.length > 30 ? content.substring(0, 30) + '...' : content;
    }
    
    saveConversations();
    renderHistory();
}

function loadConversation(id) {
    const conversation = state.conversations.find(c => c.id === id);
    if (!conversation) return;
    
    state.currentConversationId = id;
    
    elements.welcomeScreen.style.display = 'none';
    elements.messagesArea.classList.add('active');
    elements.messagesArea.innerHTML = '';
    
    conversation.messages.forEach(msg => {
        renderMessage(msg.role, msg.content, msg);
    });
    
    renderHistory();
    
    if (window.innerWidth <= 768) {
        elements.sidebar.classList.remove('open');
    }
}

function deleteConversation(id, event) {
    event.stopPropagation();
    
    state.conversations = state.conversations.filter(c => c.id !== id);
    
    if (state.currentConversationId === id) {
        startNewChat();
    }
    
    saveConversations();
    renderHistory();
    showToast('Conversation supprimée', 'success');
}

function renderHistory() {
    const container = elements.chatHistory;
    if (!container) return;
    
    container.innerHTML = '';
    
    if (state.conversations.length === 0) {
        container.innerHTML = '<div class="nav-label" style="text-align:center;padding:var(--space-lg);color:var(--text-muted)">Aucune conversation</div>';
        return;
    }
    
    state.conversations.forEach(conv => {
        const item = document.createElement('button');
        item.className = `history-item ${conv.id === state.currentConversationId ? 'active' : ''}`;
        item.innerHTML = `
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
            </svg>
            <span class="history-title">${escapeHtml(conv.title)}</span>
            <button class="history-delete" data-id="${conv.id}" title="Supprimer">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M18 6L6 18M6 6l12 12"/>
                </svg>
            </button>
        `;
        
        const deleteBtn = item.querySelector('.history-delete');
        deleteBtn.addEventListener('click', (e) => deleteConversation(conv.id, e));
        
        item.addEventListener('click', () => loadConversation(conv.id));
        container.appendChild(item);
    });
}

// ==========================================
// AFFICHAGE DES MESSAGES (avec provider)
// ==========================================
function renderMessage(role, content, metadata = {}) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${role === 'user' ? 'user' : 'ai'}`;
    messageDiv.setAttribute('data-timestamp', metadata.timestamp || new Date().toISOString());
    
    const avatar = document.createElement('div');
    avatar.className = 'message-avatar';
    avatar.textContent = role === 'user' ? '👤' : '🤖';
    
    const contentDiv = document.createElement('div');
    contentDiv.className = 'message-content';
    
    const header = document.createElement('div');
    header.className = 'message-header';
    header.innerHTML = `
        <span class="message-author">${role === 'user' ? 'Vous' : 'Moult AI'}</span>
        <span class="message-time">${new Date(metadata.timestamp || Date.now()).toLocaleTimeString()}</span>
    `;
    
    // Afficher le provider dans le message (pas dans la barre de menu)
    if (role === 'ai' && metadata.provider) {
        const providerSpan = document.createElement('span');
        providerSpan.className = 'message-provider';
        providerSpan.textContent = `via ${metadata.provider.toUpperCase()}`;
        header.appendChild(providerSpan);
    }
    
    const bubble = document.createElement('div');
    bubble.className = 'message-bubble';
    bubble.innerHTML = formatMarkdown(content);
    
    contentDiv.appendChild(header);
    contentDiv.appendChild(bubble);
    
    // Afficher le reasoning si présent
    if (metadata.reasoning && role === 'ai') {
        const reasoningBlock = document.createElement('div');
        reasoningBlock.className = 'reasoning-block';
        reasoningBlock.innerHTML = `
            <div class="reasoning-header">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polygon points="12 2 2 7 12 12 22 7 12 2"/>
                    <polyline points="2 17 12 22 22 17"/>
                    <polyline points="2 12 12 17 22 12"/>
                </svg>
                <span>Raisonnement affiché</span>
            </div>
            <div class="reasoning-content">${escapeHtml(metadata.reasoning)}</div>
        `;
        
        const reasoningHeader = reasoningBlock.querySelector('.reasoning-header');
        const reasoningContent = reasoningBlock.querySelector('.reasoning-content');
        reasoningHeader.addEventListener('click', () => {
            reasoningContent.classList.toggle('collapsed');
        });
        
        contentDiv.appendChild(reasoningBlock);
    }
    
    // Actions (copier)
    const actions = document.createElement('div');
    actions.className = 'message-actions';
    actions.innerHTML = `
        <button class="message-action copy-action" title="Copier">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <rect x="9" y="9" width="13" height="13" rx="2" ry="2"/>
                <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>
            </svg>
            Copier
        </button>
    `;
    
    actions.querySelector('.copy-action')?.addEventListener('click', () => {
        navigator.clipboard.writeText(content);
        showToast('Copié dans le presse-papier', 'success');
    });
    
    contentDiv.appendChild(actions);
    
    messageDiv.appendChild(avatar);
    messageDiv.appendChild(contentDiv);
    
    elements.messagesArea.appendChild(messageDiv);
    scrollToBottom();
}

function renderStreamingMessage(messageId) {
    const messageDiv = document.createElement('div');
    messageDiv.className = 'message ai streaming';
    messageDiv.id = messageId;
    messageDiv.setAttribute('data-timestamp', new Date().toISOString());
    
    const avatar = document.createElement('div');
    avatar.className = 'message-avatar';
    avatar.textContent = '🤖';
    
    const contentDiv = document.createElement('div');
    contentDiv.className = 'message-content';
    
    const header = document.createElement('div');
    header.className = 'message-header';
    header.innerHTML = `
        <span class="message-author">Moult AI</span>
        <span class="message-time">...</span>
        <span class="message-provider">via ${state.currentProvider.toUpperCase()}</span>
    `;
    
    const bubble = document.createElement('div');
    bubble.className = 'message-bubble';
    bubble.innerHTML = '<span class="typing-cursor">▌</span>';
    
    contentDiv.appendChild(header);
    contentDiv.appendChild(bubble);
    messageDiv.appendChild(avatar);
    messageDiv.appendChild(contentDiv);
    
    elements.messagesArea.appendChild(messageDiv);
    scrollToBottom();
    
    return messageDiv;
}

function updateStreamingMessage(messageId, content) {
    const messageDiv = document.getElementById(messageId);
    if (!messageDiv) return;
    
    const bubble = messageDiv.querySelector('.message-bubble');
    if (bubble) {
        bubble.innerHTML = formatMarkdown(content);
        scrollToBottom();
    }
}

function finalizeStreamingMessage(messageId, content, metadata = {}) {
    const messageDiv = document.getElementById(messageId);
    if (!messageDiv) return;
    
    messageDiv.classList.remove('streaming');
    messageDiv.setAttribute('data-timestamp', new Date().toISOString());
    
    const bubble = messageDiv.querySelector('.message-bubble');
    if (bubble) {
        bubble.innerHTML = formatMarkdown(content);
    }
    
    const timeSpan = messageDiv.querySelector('.message-time');
    if (timeSpan) {
        timeSpan.textContent = new Date().toLocaleTimeString();
    }
    
    // Ajouter le provider si présent
    if (metadata.provider) {
        const header = messageDiv.querySelector('.message-header');
        if (header && !header.querySelector('.message-provider')) {
            const providerSpan = document.createElement('span');
            providerSpan.className = 'message-provider';
            providerSpan.textContent = `via ${metadata.provider.toUpperCase()}`;
            header.appendChild(providerSpan);
        }
    }
    
    // Ajouter les actions
    const contentDiv = messageDiv.querySelector('.message-content');
    if (contentDiv && !contentDiv.querySelector('.message-actions')) {
        const actions = document.createElement('div');
        actions.className = 'message-actions';
        actions.innerHTML = `
            <button class="message-action copy-action" title="Copier">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <rect x="9" y="9" width="13" height="13" rx="2" ry="2"/>
                    <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>
                </svg>
                Copier
            </button>
        `;
        actions.querySelector('.copy-action')?.addEventListener('click', () => {
            navigator.clipboard.writeText(content);
            showToast('Copié dans le presse-papier', 'success');
        });
        contentDiv.appendChild(actions);
    }
    
    scrollToBottom();
}

function formatMarkdown(text) {
    // Conversion simple Markdown -> HTML
    let html = escapeHtml(text);
    
    // Code blocks
    html = html.replace(/```(\w*)\n([\s\S]*?)```/g, '<pre><code class="language-$1">$2</code></pre>');
    // Inline code
    html = html.replace(/`([^`]+)`/g, '<code>$1</code>');
    // Bold
    html = html.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
    // Italic
    html = html.replace(/\*([^*]+)\*/g, '<em>$1</em>');
    // Line breaks
    html = html.replace(/\n/g, '<br>');
    
    return html;
}

// ==========================================
// ENVOI DE MESSAGES
// ==========================================
function handleInput() {
    const value = elements.messageInput.value;
    const length = value.length;
    
    elements.charCount.textContent = `${length} / 4000`;
    elements.sendBtn.disabled = length === 0 || state.isLoading;
    
    elements.messageInput.style.height = 'auto';
    elements.messageInput.style.height = Math.min(elements.messageInput.scrollHeight, 200) + 'px';
}

function handleKeydown(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        if (!elements.sendBtn.disabled) {
            sendMessage();
        }
    }
}

async function sendMessage() {
    const message = elements.messageInput.value.trim();
    if (!message || state.isLoading) return;
    
    let conversation = getCurrentConversation();
    if (!conversation) {
        conversation = createConversation(message.substring(0, 30) + (message.length > 30 ? '...' : ''));
    }
    
    elements.welcomeScreen.style.display = 'none';
    elements.messagesArea.classList.add('active');
    
    addMessageToConversation('user', message);
    renderMessage('user', message);
    
    elements.messageInput.value = '';
    handleInput();
    
    await sendToServer(message, conversation);
}

async function sendToServer(message, conversation) {
    state.isLoading = true;
    elements.sendBtn.disabled = true;
    
    const typingId = showTypingIndicator();
    const stream = elements.streamToggle?.checked || false;
    const reasoning = elements.reasoningToggle?.checked || false;
    const mode = elements.modeSelect?.value || 'default';
    
    const history = (conversation.messages || [])
        .slice(-20)
        .filter(m => m.role === 'user' || m.role === 'assistant')
        .map(m => ({ role: m.role, content: m.content }));
    
    try {
        const response = await fetch(`${state.settings.serverUrl}/api/chat`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                message,
                provider: state.currentProvider,
                model: state.currentModel,
                mode,
                reasoning,
                stream,
                history
            })
        });
        
        removeTypingIndicator(typingId);
        
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }
        
        if (stream) {
            await handleStreamResponse(response, conversation);
        } else {
            await handleNormalResponse(response, conversation);
        }
        
    } catch (error) {
        removeTypingIndicator(typingId);
        showErrorMessage(`Erreur de connexion: ${error.message}`);
        state.isLoading = false;
        elements.sendBtn.disabled = false;
    }
}

async function handleNormalResponse(response, conversation) {
    const data = await response.json();
    
    if (data.error) {
        showErrorMessage(data.message || data.error || 'Une erreur est survenue');
        state.isLoading = false;
        elements.sendBtn.disabled = false;
        return;
    }
    
    const content = data.message || 'Pas de réponse';
    
    addMessageToConversation('assistant', content, {
        provider: data.provider || state.currentProvider,
        model: data.model || state.currentModel,
        reasoning: data.reasoning
    });
    
    renderMessage('assistant', content, {
        provider: data.provider || state.currentProvider,
        model: data.model || state.currentModel,
        reasoning: data.reasoning
    });
    
    state.isLoading = false;
    elements.sendBtn.disabled = false;
}

async function handleStreamResponse(response, conversation) {
    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let fullContent = '';
    let reasoningContent = '';
    let messageId = 'msg-' + Date.now();
    
    renderStreamingMessage(messageId);
    
    try {
        while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            
            const chunk = decoder.decode(value, { stream: true });
            const lines = chunk.split('\n');
            
            for (const line of lines) {
                if (line.startsWith('data: ')) {
                    const data = line.slice(6);
                    if (data === '[DONE]') continue;
                    
                    try {
                        const parsed = JSON.parse(data);
                        
                        if (parsed.error) {
                            throw new Error(parsed.error);
                        }
                        
                        const delta = parsed.choices?.[0]?.delta;
                        if (delta?.content) {
                            fullContent += delta.content;
                            updateStreamingMessage(messageId, fullContent);
                        }
                        
                        if (delta?.reasoning) {
                            reasoningContent += delta.reasoning;
                        }
                        
                    } catch (e) {
                        // Ignorer les erreurs de parsing
                    }
                }
            }
        }
        
        finalizeStreamingMessage(messageId, fullContent, {
            provider: state.currentProvider,
            model: state.currentModel,
            reasoning: reasoningContent
        });
        
        addMessageToConversation('assistant', fullContent, {
            provider: state.currentProvider,
            model: state.currentModel,
            reasoning: reasoningContent
        });
        
    } catch (error) {
        console.error('Stream error:', error);
        finalizeStreamingMessage(messageId, `Erreur: ${error.message}`, {});
    } finally {
        state.isLoading = false;
        elements.sendBtn.disabled = false;
    }
}

// ==========================================
// EXPORT (ZIP)
// ==========================================
async function exportAllConversations() {
    if (typeof JSZip === 'undefined') {
        showToast('Chargement de la bibliothèque...', 'warning');
        await loadJSZip();
    }
    
    const zip = new JSZip();
    const format = 'json'; // Format par défaut
    
    for (const conv of state.conversations) {
        const safeTitle = conv.title.replace(/[^a-z0-9]/gi, '_').substring(0, 50);
        const dateStr = new Date(conv.createdAt).toISOString().split('T')[0];
        const filename = `${safeTitle}_${dateStr}`;
        
        let content = JSON.stringify(conv, null, 2);
        zip.file(`${filename}.json`, content);
    }
    
    const blob = await zip.generateAsync({ type: 'blob' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `moult-ai-conversations-${Date.now()}.zip`;
    a.click();
    URL.revokeObjectURL(url);
    showToast('Export terminé', 'success');
}

function loadJSZip() {
    return new Promise((resolve, reject) => {
        const script = document.createElement('script');
        script.src = 'https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js';
        script.onload = resolve;
        script.onerror = reject;
        document.head.appendChild(script);
    });
}

// ==========================================
// UI UTILITIES
// ==========================================
function showTypingIndicator() {
    const id = 'typing-' + Date.now();
    const indicator = document.createElement('div');
    indicator.className = 'message ai typing';
    indicator.id = id;
    indicator.innerHTML = `
        <div class="message-avatar">🤖</div>
        <div class="message-content">
            <div class="typing-indicator">
                <span></span><span></span><span></span>
            </div>
        </div>
    `;
    elements.messagesArea.appendChild(indicator);
    scrollToBottom();
    return id;
}

function removeTypingIndicator(id) {
    const indicator = document.getElementById(id);
    if (indicator) indicator.remove();
}

function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerHTML = `
        <span>${type === 'success' ? '✓' : type === 'error' ? '✗' : 'ℹ'}</span>
        <span>${escapeHtml(message)}</span>
    `;
    
    elements.toastContainer.appendChild(toast);
    
    setTimeout(() => {
        toast.classList.add('toast-exit');
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

function showErrorMessage(message) {
    showToast(message, 'error');
}

function scrollToBottom() {
    const container = elements.messagesArea;
    if (container) {
        container.scrollTo({
            top: container.scrollHeight,
            behavior: 'smooth'
        });
    }
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// ==========================================
// THEME
// ==========================================
function applyTheme(theme) {
    let effectiveTheme = theme;
    if (theme === 'system') {
        effectiveTheme = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    }
    
    document.documentElement.setAttribute('data-theme', effectiveTheme);
    localStorage.setItem('moult-theme', theme);
    state.settings.theme = theme;
}

function updateProviderStatusIcons(providers) {
    // Mise à jour des indicateurs visuels dans la sidebar
    const items = document.querySelectorAll('.status-item');
    items.forEach(item => {
        const provider = item.dataset.provider;
        if (providers[provider]) {
            item.classList.add('online');
            item.classList.remove('offline');
        } else {
            item.classList.add('offline');
            item.classList.remove('online');
        }
    });
}
