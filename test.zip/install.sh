#!/bin/bash

# ============================================
# MOULT-AI-WEB-BACKEND - Installation Script
# For DEDICATED IP with GitHub Pages Frontend
# ============================================

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}
╔═══════════════════════════════════════════════════════════╗
║                                                           ║
║     MOULT-AI-WEB-BACKEND - IP DEDICATED SERVER           ║
║     Bun/Hono Proxy for MiMo & OpenRouter APIs            ║
║     Frontend: GitHub Pages                                ║
║                                                           ║
╚═══════════════════════════════════════════════════════════╝
${NC}"

# Configuration
PROJECT_DIR="/var/www/moult-ai-web-backend"
PORT=3000
NODE_VERSION="20"

# Get server IP automatically
SERVER_IP=$(curl -s ifconfig.me || curl -s icanhazip.com || hostname -I | awk '{print $1}')
echo -e "${GREEN}📡 Detected server IP: ${SERVER_IP}${NC}"

# Ask for GitHub Pages URL
echo -e "${YELLOW}📌 Enter your GitHub Pages URL (without https://):${NC}"
read -p "Example: yourusername.github.io/moult-ai-chat : " GITHUB_URL

# Validate input
if [ -z "$GITHUB_URL" ]; then
    echo -e "${RED}❌ GitHub Pages URL is required!${NC}"
    exit 1
fi

# Ask for API keys
echo -e "\n${YELLOW}🔑 Enter your API keys (press Enter to skip if not using):${NC}"
read -p "MiMo API Key: " MIMO_KEY
read -p "OpenRouter API Key: " OPENROUTER_KEY

# Check if running as root
if [[ $EUID -ne 0 ]]; then
   echo -e "${RED}❌ Please run as root: sudo bash $0${NC}"
   exit 1
fi

# ============================================
# STEP 1: System Update
# ============================================
echo -e "\n${GREEN}[1/7] Updating system...${NC}"
apt-get update -y
apt-get install -y curl git nginx ufw htop vim

# ============================================
# STEP 2: Install Bun
# ============================================
echo -e "\n${GREEN}[2/7] Installing Bun...${NC}"
curl -fsSL https://bun.sh/install | bash
export BUN_INSTALL="$HOME/.bun"
export PATH="$BUN_INSTALL/bin:$PATH"
echo 'export PATH="$HOME/.bun/bin:$PATH"' >> ~/.bashrc

# ============================================
# STEP 3: Create Project
# ============================================
echo -e "\n${GREEN}[3/7] Creating project...${NC}"
mkdir -p $PROJECT_DIR/logs
cd $PROJECT_DIR

# package.json
cat > package.json << 'EOF'
{
  "name": "moult-ai-web-backend",
  "version": "1.0.0",
  "type": "module",
  "scripts": {
    "start": "bun run server.ts",
    "pm2:start": "pm2 start server.ts --interpreter bun --name moult-ai-proxy"
  },
  "dependencies": {
    "hono": "^4.0.0",
    "@hono/rate-limiter": "^0.1.0"
  }
}
EOF

# ============================================
# STEP 4: Create Server (IP + GitHub Pages CORS)
# ============================================
echo -e "\n${GREEN}[4/7] Creating proxy server...${NC}"

cat > server.ts << EOF
import { Hono } from 'hono';
import { cors } from 'hono/cors';
import { rateLimiter } from 'hono-rate-limiter';
import { logger } from 'hono/logger';

// Environment variables
const MIMO_API_KEY = process.env.MIMO_API_KEY || '';
const OPENROUTER_API_KEY = process.env.OPENROUTER_API_KEY || '';
const SERVER_IP = '${SERVER_IP}';
const GITHUB_URL = '${GITHUB_URL}';

const MIMO_API_URL = 'https://api.xiaomimimo.com/v1/chat/completions';
const OPENROUTER_API_URL = 'https://openrouter.ai/api/v1/chat/completions';

const app = new Hono();

// Middleware
app.use('*', logger());

// CORS - Allow GitHub Pages and local development
app.use('/*', cors({
  origin: [
    \`https://\${GITHUB_URL}\`,
    \`http://\${GITHUB_URL}\`,
    'http://localhost:3000',
    'http://localhost:5500',
    'http://127.0.0.1:5500'
  ],
  allowMethods: ['POST', 'GET', 'OPTIONS'],
  allowHeaders: ['Content-Type', 'Authorization'],
  exposeHeaders: ['Content-Length'],
  maxAge: 86400,
  credentials: true
}));

// Rate limiter: 30 requests per minute per IP
const limiter = rateLimiter({
  windowMs: 60 * 1000,
  limit: 30,
  keyGenerator: (c) => c.req.header('x-forwarded-for') || c.req.ip || 'anonymous'
});

// Health check
app.get('/health', (c) => {
  return c.json({
    status: 'ok',
    server_ip: SERVER_IP,
    timestamp: new Date().toISOString(),
    memory: {
      rss: \`\${Math.round(process.memoryUsage().rss / 1024 / 1024)} MB\`,
      heapUsed: \`\${Math.round(process.memoryUsage().heapUsed / 1024 / 1024)} MB\`
    }
  });
});

// Available models
app.get('/api/models', (c) => {
  return c.json({
    mimo: ['mimo-v2.5-pro', 'mimo-v2-flash'],
    openrouter: [
      'openai/gpt-4-turbo',
      'openai/gpt-3.5-turbo',
      'anthropic/claude-3-haiku',
      'google/gemini-pro',
      'meta-llama/llama-2-70b-chat'
    ]
  });
});

// Main chat endpoint
app.post('/api/chat', limiter, async (c) => {
  try {
    const body = await c.req.json();
    
    if (!body.messages || !Array.isArray(body.messages)) {
      return c.json({ error: 'messages array required' }, 400);
    }
    
    const provider = body.provider || 'mimo';
    const model = body.model || (provider === 'mimo' ? 'mimo-v2.5-pro' : 'openai/gpt-3.5-turbo');
    
    const payload = {
      model: model,
      messages: body.messages,
      temperature: body.temperature || 0.8,
      max_tokens: Math.min(body.max_tokens || 4096, 4096),
      stream: body.stream || false
    };
    
    let apiUrl, headers;
    
    if (provider === 'mimo') {
      if (!MIMO_API_KEY) return c.json({ error: 'MiMo API key not configured' }, 503);
      apiUrl = MIMO_API_URL;
      headers = {
        'Content-Type': 'application/json',
        'api-key': MIMO_API_KEY
      };
    } else {
      if (!OPENROUTER_API_KEY) return c.json({ error: 'OpenRouter API key not configured' }, 503);
      apiUrl = OPENROUTER_API_URL;
      headers = {
        'Content-Type': 'application/json',
        'Authorization': \`Bearer \${OPENROUTER_API_KEY}\`,
        'HTTP-Referer': \`http://\${SERVER_IP}\`,
        'X-Title': 'Moult AI'
      };
    }
    
    if (payload.stream) {
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: headers,
        body: JSON.stringify(payload)
      });
      
      return new Response(response.body, {
        headers: {
          'Content-Type': 'text/event-stream',
          'Cache-Control': 'no-cache',
          'Access-Control-Allow-Origin': '*'
        }
      });
    }
    
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 60000);
    
    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: headers,
      body: JSON.stringify(payload),
      signal: controller.signal
    });
    
    clearTimeout(timeout);
    
    if (!response.ok) {
      const error = await response.text();
      return c.json({ error: \`\${provider} error: \${response.status}\` }, response.status);
    }
    
    const data = await response.json();
    return c.json(data);
    
  } catch (error) {
    console.error('Proxy error:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// Simple endpoint for system prompts
app.post('/api/chat/system', limiter, async (c) => {
  try {
    const { systemPrompt, userMessage, provider, model } = await c.req.json();
    
    if (!userMessage) {
      return c.json({ error: 'userMessage required' }, 400);
    }
    
    const messages = [];
    if (systemPrompt) {
      messages.push({ role: 'system', content: systemPrompt });
    }
    messages.push({ role: 'user', content: userMessage });
    
    const response = await fetch(\`http://localhost:\${process.env.PORT || 3000}/api/chat\`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ messages, provider, model })
    });
    
    const data = await response.json();
    return c.json(data);
    
  } catch (error) {
    return c.json({ error: error.message }, 500);
  }
});

// CORS preflight for all routes
app.options('*', (c) => {
  return c.text('', 204);
});

export default {
  port: parseInt(process.env.PORT || '3000'),
  fetch: app.fetch
};
EOF

# ============================================
# STEP 5: Environment File
# ============================================
echo -e "\n${GREEN}[5/7] Creating environment config...${NC}"

cat > .env << EOF
PORT=3000
MIMO_API_KEY=${MIMO_KEY}
OPENROUTER_API_KEY=${OPENROUTER_KEY}
EOF

chmod 600 .env

# ============================================
# STEP 6: Setup PM2
# ============================================
echo -e "\n${GREEN}[6/7] Setting up PM2...${NC}"

# Install Node.js for PM2
curl -fsSL https://deb.nodesource.com/setup_${NODE_VERSION}.x | bash -
apt-get install -y nodejs
npm install -g pm2

# Install Bun dependencies
~/.bun/bin/bun install

# Create PM2 config
cat > ecosystem.config.cjs << EOF
module.exports = {
  apps: [{
    name: 'moult-ai-proxy',
    script: 'server.ts',
    interpreter: '${HOME}/.bun/bin/bun',
    instances: 1,
    max_memory_restart: '300M',
    kill_timeout: 5000,
    max_restarts: 10,
    min_uptime: '10s',
    env: {
      NODE_ENV: 'production',
      PORT: 3000
    },
    error_file: '${PROJECT_DIR}/logs/err.log',
    out_file: '${PROJECT_DIR}/logs/out.log'
  }]
};
EOF

# Start with PM2
pm2 start ecosystem.config.cjs
pm2 save
pm2 startup | tail -n 1 | bash

# ============================================
# STEP 7: Nginx Configuration
# ============================================
echo -e "\n${GREEN}[7/7] Configuring Nginx...${NC}"

cat > /etc/nginx/sites-available/moult-ai << EOF
server {
    listen 80;
    server_name ${SERVER_IP};
    
    client_max_body_size 10M;
    
    # Headers for CORS
    add_header Access-Control-Allow-Origin "*" always;
    add_header Access-Control-Allow-Methods "POST, GET, OPTIONS" always;
    add_header Access-Control-Allow-Headers "Content-Type, Authorization" always;
    
    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_cache_bypass \$http_upgrade;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
        proxy_buffering off;
    }
    
    location /health {
        proxy_pass http://127.0.0.1:3000/health;
        access_log off;
    }
}
EOF

# Enable site
ln -sf /etc/nginx/sites-available/moult-ai /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl restart nginx

# Configure firewall
ufw allow 22/tcp
ufw allow 80/tcp
ufw --force enable

# ============================================
# Display Information
# ============================================
echo -e "\n${GREEN}════════════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}✅ MOULT-AI-WEB-BACKEND INSTALLATION COMPLETE!${NC}"
echo -e "${GREEN}════════════════════════════════════════════════════════════${NC}"

echo -e "\n${BLUE}📡 Server Information:${NC}"
echo -e "  • IP Address: ${GREEN}${SERVER_IP}${NC}"
echo -e "  • Proxy Port: ${GREEN}3000${NC}"
echo -e "  • API Base URL: ${GREEN}http://${SERVER_IP}:3000${NC}"
echo -e "  • Health Check: ${GREEN}http://${SERVER_IP}:3000/health${NC}"

echo -e "\n${BLUE}🔗 For GitHub Pages Frontend:${NC}"
echo -e "  • CORS allowed: ${GREEN}https://${GITHUB_URL}${NC}"
echo -e "  • Use this URL in your frontend: ${GREEN}http://${SERVER_IP}:3000/api/chat${NC}"

echo -e "\n${BLUE}📝 Quick Test Commands:${NC}"
echo -e "  ${YELLOW}# Test MiMo API${NC}"
echo -e "  curl -X POST http://${SERVER_IP}:3000/api/chat \\"
echo -e "    -H \"Content-Type: application/json\" \\"
echo -e "    -d '{\"provider\":\"mimo\",\"messages\":[{\"role\":\"user\",\"content\":\"Bonjour\"}]}'"

echo -e "\n  ${YELLOW}# Test with System Prompt${NC}"
echo -e "  curl -X POST http://${SERVER_IP}:3000/api/chat/system \\"
echo -e "    -H \"Content-Type: application/json\" \\"
echo -e "    -d '{\"systemPrompt\":\"You are a poet\",\"userMessage\":\"Write a haiku\"}'"

echo -e "\n${BLUE}🛠️  Management Commands:${NC}"
echo -e "  • View logs:     ${GREEN}pm2 logs moult-ai-proxy${NC}"
echo -e "  • Restart:       ${GREEN}pm2 restart moult-ai-proxy${NC}"
echo -e "  • Stop:          ${GREEN}pm2 stop moult-ai-proxy${NC}"
echo -e "  • Monitor:       ${GREEN}pm2 monit${NC}"
echo -e "  • RAM usage:     ${GREEN}curl http://${SERVER_IP}:3000/health | jq .memory${NC}"

echo -e "\n${BLUE}📁 Project Location:${NC} ${PROJECT_DIR}"
echo -e "${BLUE}📝 Environment:${NC} ${PROJECT_DIR}/.env"

echo -e "\n${YELLOW}⚠️  IMPORTANT for GitHub Pages:${NC}"
echo -e "  1. In your frontend JavaScript, use:"
echo -e "     ${GREEN}const PROXY_URL = 'http://${SERVER_IP}:3000';${NC}"
echo -e "  2. Your GitHub Pages site MUST be HTTPS for some browsers"
echo -e "  3. Consider adding SSL to your server for production"

echo -e "\n${GREEN}🎉 Your AI proxy is running! Point your GitHub Pages frontend to:${NC}"
echo -e "${GREEN}   http://${SERVER_IP}:3000/api/chat${NC}"
echo -e "${GREEN}════════════════════════════════════════════════════════════${NC}"
